# UNC Charlotte
# ITCS 5153 - Applied AI - Spring 2025
# Lab 3
# Adversarial Search / Game Playing
# Implements Minimax & Alpha-Beta Pruning for Connect Four.
# Student ID: 123456789

import time
import random
import math

class ConnectFourAI:
    def __init__(self, depth=3, use_alpha_beta=True):
        self.depth = depth
        self.use_alpha_beta = use_alpha_beta

    def best_move(self, game):
        """Finds the best move using Minimax or Alpha-Beta Pruning."""
        if self.use_alpha_beta:
            move, _, nodes_explored = self.alpha_beta_pruning(game, self.depth, -math.inf, math.inf, True, 0)
        else:
            move, _, nodes_explored = self.minimax(game, self.depth, True, 0)
        return move, nodes_explored

    def minimax(self, game, depth, maximizingPlayer, nodes_explored):
        """Standard Minimax algorithm for game tree search."""
        valid_moves = game.available_moves()
        is_terminal = game.is_winner(1) or game.is_winner(2) or game.is_full()
        nodes_explored += 1  

        if depth == 0 or is_terminal:
            if is_terminal:
                if game.is_winner(2):
                    return None, 1000000, nodes_explored
                elif game.is_winner(1):
                    return None, -1000000, nodes_explored
                else:
                    return None, 0, nodes_explored
            else:
                return None, self.evaluate_board(game), nodes_explored

        if maximizingPlayer:
            value = -math.inf
            best_col = random.choice(valid_moves)
            for col in valid_moves:
                game.make_move(col, 2)
                _, new_score, nodes_explored = self.minimax(game, depth - 1, False, nodes_explored)
                game.undo_move(col)
                if new_score > value:
                    value = new_score
                    best_col = col
            return best_col, value, nodes_explored

        else:
            value = math.inf
            best_col = random.choice(valid_moves)
            for col in valid_moves:
                game.make_move(col, 1)
                _, new_score, nodes_explored = self.minimax(game, depth - 1, True, nodes_explored)
                game.undo_move(col)
                if new_score < value:
                    value = new_score
                    best_col = col
            return best_col, value, nodes_explored

    def alpha_beta_pruning(self, game, depth, alpha, beta, maximizingPlayer, nodes_explored):
        """Alpha-Beta Pruning for optimized Minimax search."""
        valid_moves = game.available_moves()
        is_terminal = game.is_winner(1) or game.is_winner(2) or game.is_full()
        nodes_explored += 1  

        if depth == 0 or is_terminal:
            if is_terminal:
                if game.is_winner(2):
                    return None, 1000000, nodes_explored
                elif game.is_winner(1):
                    return None, -1000000, nodes_explored
                else:
                    return None, 0, nodes_explored
            else:
                return None, self.evaluate_board(game), nodes_explored

        if maximizingPlayer:
            value = -math.inf
            best_col = random.choice(valid_moves)
            for col in valid_moves:
                game.make_move(col, 2)
                _, new_score, nodes_explored = self.alpha_beta_pruning(game, depth - 1, alpha, beta, False, nodes_explored)
                game.undo_move(col)
                if new_score > value:
                    value = new_score
                    best_col = col
                alpha = max(alpha, value)
                if alpha >= beta:
                    break
            return best_col, value, nodes_explored

        else:
            value = math.inf
            best_col = random.choice(valid_moves)
            for col in valid_moves:
                game.make_move(col, 1)
                _, new_score, nodes_explored = self.alpha_beta_pruning(game, depth - 1, alpha, beta, True, nodes_explored)
                game.undo_move(col)
                if new_score < value:
                    value = new_score
                    best_col = col
                beta = min(beta, value)
                if alpha >= beta:
                    break
            return best_col, value, nodes_explored

    def evaluate_board(self, game):
        """Evaluates the board and assigns a heuristic score."""
        score = 0

        # AI (Yellow) winning move gets a high positive score
        if game.is_winner(2):  
            return 1000000  
        # Player (Red) winning move gets a high negative score
        elif game.is_winner(1):  
            return -1000000  

        # Reward AI for having more pieces in the center column
        center_column = [game.board[row][3] for row in range(6)]
        center_count = center_column.count(2)
        score += center_count * 3  

        # Horizontal scoring
        for row in range(6):
            row_pieces = game.board[row]
            for col in range(4):
                window = row_pieces[col:col+4]
                score += self.evaluate_window(window, 2)  
                score -= self.evaluate_window(window, 1)  

        # Vertical scoring
        for col in range(7):
            col_pieces = [game.board[row][col] for row in range(6)]
            for row in range(3):
                window = col_pieces[row:row+4]
                score += self.evaluate_window(window, 2)
                score -= self.evaluate_window(window, 1)

        # Positive diagonal scoring
        for row in range(3):
            for col in range(4):
                window = [game.board[row+i][col+i] for i in range(4)]
                score += self.evaluate_window(window, 2)
                score -= self.evaluate_window(window, 1)

        # Negative diagonal scoring
        for row in range(3, 6):
            for col in range(4):
                window = [game.board[row-i][col+i] for i in range(4)]
                score += self.evaluate_window(window, 2)
                score -= self.evaluate_window(window, 1)

        return score

    def evaluate_window(self, window, piece):
        """Scores a given set of four consecutive slots."""
        score = 0
        opponent_piece = 1 if piece == 2 else 2  

        window_list = list(window)  

        if window_list.count(piece) == 4:
            score += 100
        elif window_list.count(piece) == 3 and window_list.count(0) == 1:
            score += 5
        elif window_list.count(piece) == 2 and window_list.count(0) == 2:
            score += 2

        if window_list.count(opponent_piece) == 3 and window_list.count(0) == 1:
            score -= 4  

        return score
