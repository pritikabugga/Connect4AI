# UNC Charlotte
# ITCS 5153 - Applied AI - Spring 2025
# Lab 3
# Adversarial Search / Game Playing
# This module serves as the entry point for running the Connect Four AI.
# Student ID: 123456789

import pygame
import sys
from connect4_gui_801375576 import play

# Ensure Pygame is initialized properly
pygame.init()

if __name__ == "__main__":
    try:
        play()  # Start the game
    except Exception as e:
        print(f"An error occurred: {e}")
        pygame.quit()
        sys.exit()
