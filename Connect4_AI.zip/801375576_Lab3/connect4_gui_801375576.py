# UNC Charlotte
# ITCS 5153 - Applied AI - Spring 2025
# Lab 3 - Connect Four GUI with AI Selection
# This module implements the Pygame GUI for Connect Four.
# Student ID: 801375576

import pygame
import sys
import time
from games_801375576 import ConnectFour
from search_801375576 import ConnectFourAI

# Initialize Pygame
pygame.init()

# Get screen dimensions
infoObject = pygame.display.Info()
WIDTH, HEIGHT = infoObject.current_w, infoObject.current_h

# Create a resizable window
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
pygame.display.set_caption("Connect Four")
font = pygame.font.Font(None, 36)

# Constants
CELL_SIZE = 100
BLUE = (0, 50, 255)
WHITE = (255, 255, 255)
RED = (200, 0, 0)
YELLOW = (255, 204, 0)
BLACK = (0, 0, 0)
GRAY = (180, 180, 180)

# Game instance
game = ConnectFour()
selected_ai = "Alpha-Beta Pruning"  # Default AI selection
ai = ConnectFourAI(depth=3, use_alpha_beta=True)
turn = 1  # 1 = Player, 2 = AI
search_time = 0
move_number = 0
log_messages = []
game_over = False
ai_move_time = None

# **Positioning elements**
board_x = (WIDTH - (CELL_SIZE * 7)) // 2
board_y = 50  # Adjusted to give space from the top
info_x = board_x  # Align with board
info_y = board_y + CELL_SIZE * 6 + 10
button_x = info_x + 400  # Move right of game info
button_y = info_y  # Align with text
log_x = button_x + 200  # Move to the right of buttons
log_y = button_y + 100  # Align with buttons

# **Define UI Buttons**
button_width = 160
button_height = 50
buttons = {
    "New Game": pygame.Rect(button_x, button_y, button_width, button_height),
    "Restart": pygame.Rect(button_x, button_y + 60, button_width, button_height),
    "Exit": pygame.Rect(button_x, button_y + 120, button_width, button_height),
}

search_time_display = "0m 0.00s"  # Initialize AI search time display globally
total_nodes_explored = 0

def draw_board():
    """Draws the Connect Four game board in Pygame.
    This function updates the GUI after every move.
    """
    screen.fill(WHITE)

    # Draw game board
    pygame.draw.rect(screen, BLUE, (board_x, board_y, CELL_SIZE * 7, CELL_SIZE * 6))

    # Draw grid and pieces
    for row in range(6):
        for col in range(7):
            color = WHITE  # Empty slots
            if game.board[row][col] == 1:
                color = RED
            elif game.board[row][col] == 2:
                color = YELLOW
            pygame.draw.circle(screen, color, (board_x + col * CELL_SIZE + CELL_SIZE // 2,
                                               board_y + row * CELL_SIZE + CELL_SIZE // 2), 40)

    # Draw game info
    screen.blit(font.render(f"Turn: {'Player (Red)' if turn == 1 else 'AI (Yellow)'}", True, BLACK), (info_x, info_y))
    screen.blit(font.render(f"AI: {selected_ai}", True, BLACK), (info_x, info_y + 30))
    screen.blit(font.render(f"AI Time: {search_time_display}", True, BLACK), (info_x, info_y + 60))

    # Draw buttons
    for label, rect in buttons.items():
        pygame.draw.rect(screen, GRAY, rect, border_radius=10)
        text_surf = font.render(label, True, BLACK)
        text_rect = text_surf.get_rect(center=rect.center)
        screen.blit(text_surf, text_rect)

    # AI Node Exploration Console
    log_width = CELL_SIZE * 3.5              
    log_height = CELL_SIZE * 7
    log_x = 20
    log_y = 20

    log_font = pygame.font.Font(None, 25)

    log_rect = pygame.Rect(log_x, log_y, log_width, log_height)
    pygame.draw.rect(screen, BLACK, log_rect, border_radius=10)
    pygame.draw.rect(screen, WHITE, log_rect.inflate(-10, -10), border_radius=10)

    # Display recent node exploration history
    y_offset = log_rect.y + 10
    screen.blit(font.render("AI Search History:", True, BLACK), (log_rect.x + 10, y_offset))
    y_offset += 25

    # Scrollable Log: Show all log messages with scrolling
    log_start = max(0, len(log_messages) - 20)  # Adjust this number based on log height
    for log in log_messages[log_start:]:  # Show all messages within view
        screen.blit(log_font.render(log, True, BLACK), (log_rect.x + 10, y_offset))
        y_offset += 20  # Move down for next entry

    pygame.display.update()


def reset_game():
    """Resets the game state."""
    global game, turn, search_time, log_messages, game_over, ai_move_time
    game = ConnectFour()
    turn = 1  # Player starts
    search_time = 0
    log_messages = []
    game_over = False  # Ensure game resets
    ai_move_time = None  # Prevent AI from moving instantly after reset

    draw_board()  # Redraw the board immediately
    pygame.display.update()

def show_popup(message):
    """Displays a popup message when the game is over without causing glitches."""
    popup = pygame.Surface((400, 200))
    popup.fill(WHITE)
    pygame.draw.rect(popup, BLACK, popup.get_rect(), 5)

    # Render text
    text = font.render(message, True, BLACK)
    text_rect = text.get_rect(center=(200, 90))
    popup.blit(text, text_rect)

    # Blit to screen (only once)
    screen.blit(popup, ((WIDTH - 400) // 2, (HEIGHT - 200) // 2))
    pygame.display.update()  # Prevent excessive updates

    pygame.time.delay(1800)  # Wait 1.8 seconds to display the popup



def select_ai():
    """Prompts the user to select an AI algorithm using radio buttons."""
    global selected_ai, ai

    # Define AI options
    ai_options = ["Minimax", "Alpha-Beta Pruning"]
    selected_index = 1  # Default to Alpha-Beta Pruning

    # Radio button positions
    radio_x = WIDTH // 2 - 150
    radio_y = HEIGHT // 3

    # Create loop for selection screen
    selecting = True
    while selecting:
        screen.fill(WHITE)
        title = font.render("Select AI Algorithm", True, BLACK)
        screen.blit(title, (WIDTH // 2 - 100, radio_y - 50))

        # Draw radio buttons
        for i, label in enumerate(ai_options):
            is_selected = (i == selected_index)

            # Draw circle for radio button
            pygame.draw.circle(screen, BLACK, (radio_x, radio_y + i * 60), 10, 2)  # Outer circle
            if is_selected:
                pygame.draw.circle(screen, BLACK, (radio_x, radio_y + i * 60), 5)  # Filled circle

            # Draw text
            text_surf = font.render(label, True, BLACK)
            screen.blit(text_surf, (radio_x + 30, radio_y + i * 60 - 10))

        # Draw "Start Game" button
        start_button = pygame.Rect(WIDTH // 2 - 75, radio_y + 150, 150, 50)
        pygame.draw.rect(screen, GRAY, start_button, border_radius=10)
        text_surf = font.render("Start Game", True, BLACK)
        screen.blit(text_surf, text_surf.get_rect(center=start_button.center))

        pygame.display.update()


        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                x, y = event.pos

                # Check radio buttons
                for i in range(len(ai_options)):
                    if radio_x - 10 <= x <= radio_x + 10 and radio_y + i * 60 - 10 <= y <= radio_y + i * 60 + 10:
                        selected_index = i  # Update selection

                # Check "Start Game" button
                if start_button.collidepoint(x, y):
                    selected_ai = ai_options[selected_index]
                    ai = ConnectFourAI(depth=3, use_alpha_beta=(selected_ai == "Alpha-Beta Pruning"))
                    selecting = False  # Exit loop

def play():
    """Main game loop."""
    global turn, search_time, game_over, ai_move_time, selected_ai, ai, search_time_display, move_number

    select_ai()  # Ask the user for AI selection before starting

    running = True
    while running:
        draw_board()

        # Check for a winner or draw
        if game.is_winner(1):
            show_popup("Player Wins!")
            game_over = True
        elif game.is_winner(2):
            show_popup("AI Wins!")
            game_over = True
        elif game.is_full():
            show_popup("It's a Draw!")
            game_over = True

        # Handle user inputs (mouse clicks, closing window)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                x, y = event.pos

                # Check if a button was clicked
                if buttons["New Game"].collidepoint((x, y)):
                    select_ai()
                    reset_game()
                    continue
                elif buttons["Restart"].collidepoint((x, y)):
                    reset_game()
                    continue
                elif buttons["Exit"].collidepoint((x, y)):
                    pygame.quit()
                    sys.exit()

                # Player Move Handling
                if not game_over and turn == 1:  # Player's turn (Human)
                    if board_y < y < board_y + CELL_SIZE * 6:  # Ensure click is inside board
                        col = (x - board_x) // CELL_SIZE  # Determine column index
                        if 0 <= col < 7 and col in game.available_moves():  # Check if move is valid
                            game.make_move(col, 1)  # Place player's piece
                            turn = 2  # Switch turn to AI
                            ai_move_time = time.time() + 1.5  # Delay AI move for visualization

        # AI Move Handling
        if turn == 2 and not game_over and ai_move_time and time.time() >= ai_move_time:
            ai_start_time = time.time()  # Start timing AI move

            global total_nodes_explored
            move, nodes_explored = ai.best_move(game)  # AI selects the best move using Minimax/Alpha-Beta
            total_nodes_explored += nodes_explored  # Track nodes explored (for performance metrics)
            
            ai_end_time = time.time()  # End timing AI move
            search_time = ai_end_time - ai_start_time  # Compute AI move duration

            # Convert search time into minutes & seconds for display
            global search_time_display, move_number
            minutes = int(search_time // 60)
            seconds = search_time % 60
            search_time_display = f"{minutes}m {seconds:.2f}s"

            game.make_move(move, 2)  # AI makes the move
            move_number += 1
            log_messages.append(f"Move: {move_number} | {search_time_display} | Nodes Traced: {nodes_explored}")  # Log AI performance

            turn = 1  # Switch back to the player's turn
            ai_move_time = None  # Reset AI move timer

        pygame.display.update()

play()
