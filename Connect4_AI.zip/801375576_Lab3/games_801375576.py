# UNC Charlotte
# ITCS 5153 - Applied AI - Spring 2025
# Lab 3 - Adversarial Search / Game Playing
# This module implements the Connect Four game logic.
# Student ID: 123456789

import numpy as np

class ConnectFour:
    """Implements the rules and mechanics of Connect Four."""
    
    ROWS = 6
    COLS = 7
    EMPTY = 0
    PLAYER_X = 1  # Human (Red)
    PLAYER_O = 2  # AI (Yellow)
    
    def __init__(self):
        """Initialize an empty board."""
        self.board = np.zeros((self.ROWS, self.COLS), dtype=int)

    def available_moves(self):
        """Returns a list of columns where a move is possible."""
        return [c for c in range(self.COLS) if self.board[0][c] == self.EMPTY]

    def make_move(self, col, player):
        """Drops a piece into the given column and returns the row it landed on."""
        for row in range(self.ROWS - 1, -1, -1):
            if self.board[row][col] == self.EMPTY:
                self.board[row][col] = player
                return row  # Return the row where the piece landed
        return -1  # Column is full

    def undo_move(self, col):
        """Removes the last move from a column (used for AI simulations)."""
        for row in range(self.ROWS):
            if self.board[row][col] != self.EMPTY:
                self.board[row][col] = self.EMPTY
                return

    def is_winner(self, player):
        """Checks if the given player has won with four in a row."""
        
        # **Check horizontal win**
        for row in range(self.ROWS):
            for col in range(self.COLS - 3):  # Prevent index out-of-bounds
                if (self.board[row][col] == player and
                    self.board[row][col + 1] == player and
                    self.board[row][col + 2] == player and
                    self.board[row][col + 3] == player):
                    return True

        # **Check vertical win**
        for row in range(self.ROWS - 3):  # Prevent index out-of-bounds
            for col in range(self.COLS):
                if (self.board[row][col] == player and
                    self.board[row + 1][col] == player and
                    self.board[row + 2][col] == player and
                    self.board[row + 3][col] == player):
                    return True

        # **Check diagonal (\) from top-left to bottom-right**
        for row in range(self.ROWS - 3):
            for col in range(self.COLS - 3):
                if (self.board[row][col] == player and
                    self.board[row + 1][col + 1] == player and
                    self.board[row + 2][col + 2] == player and
                    self.board[row + 3][col + 3] == player):
                    return True

        # **Check diagonal (/) from bottom-left to top-right**
        for row in range(3, self.ROWS):  # Start from row index 3
            for col in range(self.COLS - 3):
                if (self.board[row][col] == player and
                    self.board[row - 1][col + 1] == player and
                    self.board[row - 2][col + 2] == player and
                    self.board[row - 3][col + 3] == player):
                    return True

        return False  # No winner found

    def is_full(self):
        """Checks if the board is completely filled (draw)."""
        return all(self.board[0][c] != self.EMPTY for c in range(self.COLS))

    def get_board_state(self):
        """Returns a copy of the board (for debugging/logging)."""
        return np.copy(self.board)
